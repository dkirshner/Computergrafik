#pragma once

//zur ermittlung von Pi
#define _USE_MATH_DEFINES
#include <cmath>

#include <iostream>
#include <vector>

#include <GL/glew.h>
//#include <GL/gl.h> // OpenGL header not necessary, included by GLEW
#include <GL/freeglut.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/matrix_inverse.hpp>

#include "GLSLProgram.h"
#include "GLTools.h"

// Standard window width
const int WINDOW_WIDTH = 640;
// Standard window height
const int WINDOW_HEIGHT = 480;

/*
Struct to hold data for object rendering.
*/
struct Object
{
	/* IDs for several buffers. */
	GLuint vao;

	GLuint positionBuffer;
	GLuint colorBuffer;

	GLuint indexBuffer;

	/* Model matrix */
	glm::mat4x4 model;
};
/////////////////////////////////////
const int MIN_COUNT_TRIANGLE = 3;
const int MAX_COUNT_TRIANGLE = 30;
////////////////////////////////////
// Prototypen
void renderTriangle(Object a_triangle);
void initTriangle(const std::vector<glm::vec3> a_vertices, const std::vector<glm::vec3> a_colors, Object& a_triangle);
bool initAllTriangles(void);
void renderCircle();
