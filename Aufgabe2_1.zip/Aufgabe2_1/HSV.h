#pragma once
#include <iostream>	 // cout
using namespace std;

class HSV
{
public:
	double H;
	double S;
	double V;

	HSV(double h, double s, double v)
	{
		H = h;
		S = s;
		V = v;
	}

	bool Equals(HSV hsv)
	{
		return (H == hsv.H) && (S == hsv.S) && (V == hsv.V);
	}

	void Output(void)
	{
		cout << "---  HSV Ausgabe ---" << endl;
		cout << "H:" << (double)H << " (Grad)" << endl;
		cout << "S:" << (double)(S*100.0) << " (Prozent)" << endl;
		cout << "V:" << (double)(V*100.0) << " (Prozent)" << endl;
	}
};
