#include "CMY.h"

static CMY RGBToCMY(RGB rgb) {
	// normalisierung der Farbwerte RGB in intervall [0,1]
	double dr = (double)rgb.R / 255;
	double dg = (double)rgb.G / 255;
	double db = (double)rgb.B / 255;

	double c = (1 - dr);
	double m = (1 - dg);
	double y = (1 - db);

	return CMY(c, m, y);
}

static RGB CMYToRGB(CMY cmy) {
	unsigned char r = (unsigned char)(255 * (1 - cmy.C));
	unsigned char g = (unsigned char)(255 * (1 - cmy.M));
	unsigned char b = (unsigned char)(255 * (1 - cmy.Y));

	return RGB(r, g, b);
}