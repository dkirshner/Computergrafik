#pragma once
#include <iostream>	 // cout
using namespace std;
class CMY
{
public:
	double C;
	double M;
	double Y;

	CMY(double c, double m, double y)
	{
		C = c;
		M = m;
		Y = y;
	}

	bool Equals(CMY cmy)
	{
		return (C == cmy.C) && (M == cmy.M) && (Y == cmy.Y);
	}

	void Output(void)
	{
		// CMY Ausgabe
		cout << "---  CMY Ausgabe ---"<< endl;
		cout << "C:" << (double)(C * 100) << " (Prozent)" << endl;
		cout << "M:" << (double)(M * 100) << " (Prozent)" << endl;
		cout << "Y:" << (double)(Y * 100) << " (Prozent)" << endl;
	}
};